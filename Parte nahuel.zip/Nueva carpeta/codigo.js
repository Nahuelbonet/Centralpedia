var Nombre = prompt("Nombre y apellido")

alert(Nombre)